package com.example.recycling.controller;

import com.example.recycling.dto.BonusEntryDto;
import com.example.recycling.entity.BonusEntry;
import com.example.recycling.service.BonusEntryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/bonus-entries")
public class BonusEntryController {

    private final BonusEntryService bonusEntryService;

    public BonusEntryController(BonusEntryService bonusEntryService) {
        this.bonusEntryService = bonusEntryService;
    }

    @GetMapping
    public ResponseEntity<List<BonusEntryDto>> getAllBonusEntries() {
        List<BonusEntryDto> dtos = bonusEntryService.getAllBonusEntries().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BonusEntryDto> getBonusEntryById(@PathVariable Long id) {
        BonusEntry bonus = bonusEntryService.getBonusEntryById(id);
        return ResponseEntity.ok(toDto(bonus));
    }

    @PostMapping
    public ResponseEntity<BonusEntryDto> createBonusEntry(@RequestBody BonusEntryDto dto) {
        BonusEntry created = bonusEntryService.createBonusEntry(
                dto.getBatchId(),
                dto.getPoints(),
                dto.getAccrualStatus()
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(toDto(created));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<BonusEntryDto> updateBonusEntry(@PathVariable Long id, @RequestBody BonusEntryDto dto) {
        BonusEntry updated = bonusEntryService.updateBonusEntry(
                id,
                dto.getBatchId(),
                dto.getPoints(),
                dto.getAccrualStatus()
        );
        return ResponseEntity.ok(toDto(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBonusEntry(@PathVariable Long id) {
        bonusEntryService.deleteBonusEntry(id);
        return ResponseEntity.noContent().build();
    }

    private BonusEntryDto toDto(BonusEntry entity) {
        return new BonusEntryDto(
                entity.getId(),
                entity.getRecyclingBatch() != null ? entity.getRecyclingBatch().getId() : null,
                entity.getPoints(),
                entity.getAccrualStatus()
        );
    }
}
