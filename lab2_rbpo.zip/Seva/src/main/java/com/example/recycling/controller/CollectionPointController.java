package com.example.recycling.controller;

import com.example.recycling.dto.CollectionPointDto;
import com.example.recycling.entity.CollectionPoint;
import com.example.recycling.entity.RecyclingType;
import com.example.recycling.service.CollectionPointService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/collection-points")
public class CollectionPointController {

    private final CollectionPointService collectionPointService;

    public CollectionPointController(CollectionPointService collectionPointService) {
        this.collectionPointService = collectionPointService;
    }

    @GetMapping
    public ResponseEntity<List<CollectionPointDto>> getAllPoints() {
        List<CollectionPointDto> dtos = collectionPointService.getAllPoints().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CollectionPointDto> getPointById(@PathVariable Long id) {
        CollectionPoint point = collectionPointService.getPointById(id);
        return ResponseEntity.ok(toDto(point));
    }

    @PostMapping
    public ResponseEntity<CollectionPointDto> createPoint(@RequestBody CollectionPointDto dto) {
        CollectionPoint point = new CollectionPoint();
        point.setAddress(dto.getAddress());
        point.setAvailable(dto.getAvailable());
        point.setDailyWeightLimit(dto.getDailyWeightLimit());

        CollectionPoint created = collectionPointService.createPoint(point, dto.getAcceptedTypeIds());
        return ResponseEntity.status(HttpStatus.CREATED).body(toDto(created));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<CollectionPointDto> updatePoint(@PathVariable Long id, @RequestBody CollectionPointDto dto) {
        CollectionPoint patchData = new CollectionPoint();
        patchData.setAddress(dto.getAddress());
        patchData.setAvailable(dto.getAvailable());
        patchData.setDailyWeightLimit(dto.getDailyWeightLimit());

        CollectionPoint updated = collectionPointService.updatePoint(id, patchData, dto.getAcceptedTypeIds());
        return ResponseEntity.ok(toDto(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePoint(@PathVariable Long id) {
        collectionPointService.deletePoint(id);
        return ResponseEntity.noContent().build();
    }

    private CollectionPointDto toDto(CollectionPoint point) {
        Set<Long> acceptedTypeIds = point.getAcceptedTypes().stream()
                .map(RecyclingType::getId)
                .collect(Collectors.toSet());

        return new CollectionPointDto(
                point.getId(),
                point.getAddress(),
                acceptedTypeIds,
                point.getAvailable(),
                point.getDailyWeightLimit()
        );
    }
}
