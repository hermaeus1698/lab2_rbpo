package com.example.recycling.controller;

import com.example.recycling.dto.RecyclingBatchDto;
import com.example.recycling.entity.RecyclingBatch;
import com.example.recycling.service.RecyclingBatchService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/recycling-batches")
public class RecyclingBatchController {

    private final RecyclingBatchService recyclingBatchService;

    public RecyclingBatchController(RecyclingBatchService recyclingBatchService) {
        this.recyclingBatchService = recyclingBatchService;
    }

    @GetMapping
    public ResponseEntity<List<RecyclingBatchDto>> getAllBatches() {
        List<RecyclingBatchDto> dtos = recyclingBatchService.getAllBatches().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RecyclingBatchDto> getBatchById(@PathVariable Long id) {
        RecyclingBatch batch = recyclingBatchService.getBatchById(id);
        return ResponseEntity.ok(toDto(batch));
    }

    @PostMapping
    public ResponseEntity<RecyclingBatchDto> createBatch(@RequestBody RecyclingBatchDto dto) {

        RecyclingBatch created = recyclingBatchService.createBatch(
                dto.getUserId(),
                dto.getPointId(),
                dto.getTypeId(),
                dto.getWeight(),
                dto.getStatus()
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(toDto(created));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<RecyclingBatchDto> updateBatch(@PathVariable Long id, @RequestBody RecyclingBatchDto dto) {
        RecyclingBatch updated = recyclingBatchService.updateBatch(
                id,
                dto.getUserId(),
                dto.getPointId(),
                dto.getTypeId(),
                dto.getWeight(),
                dto.getStatus()
        );
        return ResponseEntity.ok(toDto(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBatch(@PathVariable Long id) {
        recyclingBatchService.deleteBatch(id);
        return ResponseEntity.noContent().build();
    }

    private RecyclingBatchDto toDto(RecyclingBatch batch) {
        return new RecyclingBatchDto(
                batch.getId(),
                batch.getUser() != null ? batch.getUser().getId() : null,
                batch.getCollectionPoint() != null ? batch.getCollectionPoint().getId() : null,
                batch.getRecyclingType() != null ? batch.getRecyclingType().getId() : null,
                batch.getWeight(),
                batch.getReceptionDate(),
                batch.getStatus()
        );
    }
}
