package com.example.recycling.controller;

import com.example.recycling.dto.RecyclingTypeDto;
import com.example.recycling.entity.RecyclingType;
import com.example.recycling.service.RecyclingTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/recycling-types")
public class RecyclingTypeController {

    private final RecyclingTypeService recyclingTypeService;

    public RecyclingTypeController(RecyclingTypeService recyclingTypeService) {
        this.recyclingTypeService = recyclingTypeService;
    }

    @GetMapping
    public ResponseEntity<List<RecyclingTypeDto>> getAllTypes() {
        List<RecyclingTypeDto> dtos = recyclingTypeService.getAllTypes().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RecyclingTypeDto> getTypeById(@PathVariable Long id) {
        RecyclingType type = recyclingTypeService.getTypeById(id);
        return ResponseEntity.ok(toDto(type));
    }

    @PostMapping
    public ResponseEntity<RecyclingTypeDto> createType(@RequestBody RecyclingTypeDto dto) {
        RecyclingType type = toEntity(dto);
        RecyclingType created = recyclingTypeService.createType(type);
        return ResponseEntity.status(HttpStatus.CREATED).body(toDto(created));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<RecyclingTypeDto> updateType(@PathVariable Long id, @RequestBody RecyclingTypeDto dto) {
        RecyclingType patchData = toEntity(dto);
        RecyclingType updated = recyclingTypeService.updateType(id, patchData);
        return ResponseEntity.ok(toDto(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteType(@PathVariable Long id) {
        recyclingTypeService.deleteType(id);
        return ResponseEntity.noContent().build();
    }

    private RecyclingTypeDto toDto(RecyclingType entity) {
        return new RecyclingTypeDto(entity.getId(), entity.getName(), entity.getUnit(), entity.getPointsPerKg());
    }

    private RecyclingType toEntity(RecyclingTypeDto dto) {
        return new RecyclingType(dto.getId(), dto.getName(), dto.getUnit(), dto.getPointsPerKg());
    }
}
