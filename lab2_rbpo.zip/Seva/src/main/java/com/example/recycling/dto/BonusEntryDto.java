package com.example.recycling.dto;

public class BonusEntryDto {
    private Long id;
    private Long batchId;
    private Double points;
    private String accrualStatus;

    public BonusEntryDto() {
    }

    public BonusEntryDto(Long id, Long batchId, Double points, String accrualStatus) {
        this.id = id;
        this.batchId = batchId;
        this.points = points;
        this.accrualStatus = accrualStatus;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBatchId() {
        return batchId;
    }

    public void setBatchId(Long batchId) {
        this.batchId = batchId;
    }

    public Double getPoints() {
        return points;
    }

    public void setPoints(Double points) {
        this.points = points;
    }

    public String getAccrualStatus() {
        return accrualStatus;
    }

    public void setAccrualStatus(String accrualStatus) {
        this.accrualStatus = accrualStatus;
    }
}
