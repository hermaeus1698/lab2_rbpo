package com.example.recycling.dto;

import java.util.HashSet;
import java.util.Set;

public class CollectionPointDto {
    private Long id;
    private String address;
    private Set<Long> acceptedTypeIds = new HashSet<>();
    private Boolean available;
    private Double dailyWeightLimit;

    public CollectionPointDto() {
    }

    public CollectionPointDto(Long id, String address, Set<Long> acceptedTypeIds, Boolean available, Double dailyWeightLimit) {
        this.id = id;
        this.address = address;
        this.acceptedTypeIds = acceptedTypeIds != null ? acceptedTypeIds : new HashSet<>();
        this.available = available;
        this.dailyWeightLimit = dailyWeightLimit;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Set<Long> getAcceptedTypeIds() {
        return acceptedTypeIds;
    }

    public void setAcceptedTypeIds(Set<Long> acceptedTypeIds) {
        this.acceptedTypeIds = acceptedTypeIds;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public Double getDailyWeightLimit() {
        return dailyWeightLimit;
    }

    public void setDailyWeightLimit(Double dailyWeightLimit) {
        this.dailyWeightLimit = dailyWeightLimit;
    }
}
