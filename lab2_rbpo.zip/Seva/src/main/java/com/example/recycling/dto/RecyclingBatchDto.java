package com.example.recycling.dto;

import java.time.LocalDateTime;

public class RecyclingBatchDto {
    private Long id;
    private Long userId;
    private Long pointId;
    private Long typeId;
    private Double weight;
    private LocalDateTime receptionDate;
    private String status;

    public RecyclingBatchDto() {
    }

    public RecyclingBatchDto(Long id, Long userId, Long pointId, Long typeId, Double weight, LocalDateTime receptionDate, String status) {
        this.id = id;
        this.userId = userId;
        this.pointId = pointId;
        this.typeId = typeId;
        this.weight = weight;
        this.receptionDate = receptionDate;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getPointId() {
        return pointId;
    }

    public void setPointId(Long pointId) {
        this.pointId = pointId;
    }

    public Long getTypeId() {
        return typeId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public LocalDateTime getReceptionDate() {
        return receptionDate;
    }

    public void setReceptionDate(LocalDateTime receptionDate) {
        this.receptionDate = receptionDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
