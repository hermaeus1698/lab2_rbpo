package com.example.recycling.dto;

public class RecyclingTypeDto {
    private Long id;
    private String name;
    private String unit;
    private Double pointsPerKg;

    public RecyclingTypeDto() {
    }

    public RecyclingTypeDto(Long id, String name, String unit, Double pointsPerKg) {
        this.id = id;
        this.name = name;
        this.unit = unit;
        this.pointsPerKg = pointsPerKg;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Double getPointsPerKg() {
        return pointsPerKg;
    }

    public void setPointsPerKg(Double pointsPerKg) {
        this.pointsPerKg = pointsPerKg;
    }
}
