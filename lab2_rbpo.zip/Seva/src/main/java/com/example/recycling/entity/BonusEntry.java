package com.example.recycling.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "bonus_entries")
public class BonusEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "batch_id", nullable = false)
    private RecyclingBatch recyclingBatch;

    @Column(nullable = false)
    private Double points;

    @Column(nullable = false)
    private String accrualStatus;

    public BonusEntry() {
    }

    public BonusEntry(Long id, RecyclingBatch recyclingBatch, Double points, String accrualStatus) {
        this.id = id;
        this.recyclingBatch = recyclingBatch;
        this.points = points;
        this.accrualStatus = accrualStatus;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public RecyclingBatch getRecyclingBatch() {
        return recyclingBatch;
    }

    public void setRecyclingBatch(RecyclingBatch recyclingBatch) {
        this.recyclingBatch = recyclingBatch;
    }

    public Double getPoints() {
        return points;
    }

    public void setPoints(Double points) {
        this.points = points;
    }

    public String getAccrualStatus() {
        return accrualStatus;
    }

    public void setAccrualStatus(String accrualStatus) {
        this.accrualStatus = accrualStatus;
    }
}
