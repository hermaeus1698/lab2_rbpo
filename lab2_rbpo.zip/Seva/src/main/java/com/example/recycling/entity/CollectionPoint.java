package com.example.recycling.entity;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "collection_points")
public class CollectionPoint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String address;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "collection_point_recycling_types",
            joinColumns = @JoinColumn(name = "collection_point_id"),
            inverseJoinColumns = @JoinColumn(name = "recycling_type_id")
    )
    private Set<RecyclingType> acceptedTypes = new HashSet<>();

    @Column(nullable = false)
    private Boolean available = true;

    @Column(nullable = false)
    private Double dailyWeightLimit;

    public CollectionPoint() {
    }

    public CollectionPoint(Long id, String address, Set<RecyclingType> acceptedTypes, Boolean available, Double dailyWeightLimit) {
        this.id = id;
        this.address = address;
        this.acceptedTypes = acceptedTypes != null ? acceptedTypes : new HashSet<>();
        this.available = available != null ? available : true;
        this.dailyWeightLimit = dailyWeightLimit;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Set<RecyclingType> getAcceptedTypes() {
        return acceptedTypes;
    }

    public void setAcceptedTypes(Set<RecyclingType> acceptedTypes) {
        this.acceptedTypes = acceptedTypes;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public Double getDailyWeightLimit() {
        return dailyWeightLimit;
    }

    public void setDailyWeightLimit(Double dailyWeightLimit) {
        this.dailyWeightLimit = dailyWeightLimit;
    }
}
