package com.example.recycling.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "recycling_batches")
public class RecyclingBatch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "collection_point_id", nullable = false)
    private CollectionPoint collectionPoint;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "recycling_type_id", nullable = false)
    private RecyclingType recyclingType;

    @Column(nullable = false)
    private Double weight;

    @Column(nullable = false)
    private LocalDateTime receptionDate;

    @Column(nullable = false)
    private String status;

    public RecyclingBatch() {
    }

    public RecyclingBatch(Long id, User user, CollectionPoint collectionPoint, RecyclingType recyclingType, Double weight, LocalDateTime receptionDate, String status) {
        this.id = id;
        this.user = user;
        this.collectionPoint = collectionPoint;
        this.recyclingType = recyclingType;
        this.weight = weight;
        this.receptionDate = receptionDate;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public CollectionPoint getCollectionPoint() {
        return collectionPoint;
    }

    public void setCollectionPoint(CollectionPoint collectionPoint) {
        this.collectionPoint = collectionPoint;
    }

    public RecyclingType getRecyclingType() {
        return recyclingType;
    }

    public void setRecyclingType(RecyclingType recyclingType) {
        this.recyclingType = recyclingType;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public LocalDateTime getReceptionDate() {
        return receptionDate;
    }

    public void setReceptionDate(LocalDateTime receptionDate) {
        this.receptionDate = receptionDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
