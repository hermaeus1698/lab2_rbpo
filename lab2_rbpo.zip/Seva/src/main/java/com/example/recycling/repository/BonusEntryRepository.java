package com.example.recycling.repository;

import com.example.recycling.entity.BonusEntry;
import com.example.recycling.entity.RecyclingBatch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository
public interface BonusEntryRepository extends JpaRepository<BonusEntry, Long> {
    List<BonusEntry> findByRecyclingBatchId(Long batchId);
    List<BonusEntry> findByRecyclingBatchIn(Collection<RecyclingBatch> batches);
    void deleteByRecyclingBatchId(Long batchId);
}
