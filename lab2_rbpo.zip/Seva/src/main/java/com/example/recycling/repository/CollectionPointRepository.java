package com.example.recycling.repository;

import com.example.recycling.entity.CollectionPoint;
import com.example.recycling.entity.RecyclingType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CollectionPointRepository extends JpaRepository<CollectionPoint, Long> {
    List<CollectionPoint> findByAcceptedTypesContaining(RecyclingType recyclingType);
}
