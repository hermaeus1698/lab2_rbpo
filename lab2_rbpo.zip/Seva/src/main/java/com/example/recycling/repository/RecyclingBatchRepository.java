package com.example.recycling.repository;

import com.example.recycling.entity.RecyclingBatch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RecyclingBatchRepository extends JpaRepository<RecyclingBatch, Long> {
    List<RecyclingBatch> findByUserId(Long userId);
    List<RecyclingBatch> findByCollectionPointId(Long collectionPointId);
    List<RecyclingBatch> findByRecyclingTypeId(Long recyclingTypeId);
}
