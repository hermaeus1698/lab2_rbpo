package com.example.recycling.repository;

import com.example.recycling.entity.RecyclingType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecyclingTypeRepository extends JpaRepository<RecyclingType, Long> {
}
