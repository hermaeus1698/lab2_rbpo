package com.example.recycling.service;

import com.example.recycling.entity.BonusEntry;
import com.example.recycling.entity.RecyclingBatch;
import com.example.recycling.exception.ResourceNotFoundException;
import com.example.recycling.repository.BonusEntryRepository;
import com.example.recycling.repository.RecyclingBatchRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class BonusEntryService {

    private final BonusEntryRepository bonusEntryRepository;
    private final RecyclingBatchRepository recyclingBatchRepository;

    public BonusEntryService(BonusEntryRepository bonusEntryRepository,
                             RecyclingBatchRepository recyclingBatchRepository) {
        this.bonusEntryRepository = bonusEntryRepository;
        this.recyclingBatchRepository = recyclingBatchRepository;
    }

    @Transactional(readOnly = true)
    public List<BonusEntry> getAllBonusEntries() {
        return bonusEntryRepository.findAll();
    }

    @Transactional(readOnly = true)
    public BonusEntry getBonusEntryById(Long id) {
        return bonusEntryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Бонусная запись с id " + id + " не найдена"));
    }

    public BonusEntry createBonusEntry(Long batchId, Double points, String accrualStatus) {
        RecyclingBatch batch = recyclingBatchRepository.findById(batchId)
                .orElseThrow(() -> new ResourceNotFoundException("Партия с id " + batchId + " не найдена"));

        Double calculatedPoints = points;
        if (calculatedPoints == null) {
            Double pointsPerKg = batch.getRecyclingType() != null ? batch.getRecyclingType().getPointsPerKg() : 0.0;
            Double weight = batch.getWeight() != null ? batch.getWeight() : 0.0;
            calculatedPoints = weight * pointsPerKg;
        }

        BonusEntry bonus = new BonusEntry();
        bonus.setRecyclingBatch(batch);
        bonus.setPoints(calculatedPoints);
        bonus.setAccrualStatus(accrualStatus != null ? accrualStatus : "ACCRUED");

        return bonusEntryRepository.save(bonus);
    }

    public BonusEntry updateBonusEntry(Long id, Long batchId, Double points, String accrualStatus) {
        BonusEntry existing = getBonusEntryById(id);

        if (batchId != null) {
            RecyclingBatch batch = recyclingBatchRepository.findById(batchId)
                    .orElseThrow(() -> new ResourceNotFoundException("Партия с id " + batchId + " не найдена"));
            existing.setRecyclingBatch(batch);
        }
        if (points != null) {
            existing.setPoints(points);
        }
        if (accrualStatus != null) {
            existing.setAccrualStatus(accrualStatus);
        }

        return bonusEntryRepository.save(existing);
    }

    public void deleteBonusEntry(Long id) {
        BonusEntry bonus = getBonusEntryById(id);
        bonusEntryRepository.delete(bonus);
    }
}
