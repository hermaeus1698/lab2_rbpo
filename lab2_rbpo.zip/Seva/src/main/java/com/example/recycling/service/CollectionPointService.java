package com.example.recycling.service;

import com.example.recycling.entity.BonusEntry;
import com.example.recycling.entity.CollectionPoint;
import com.example.recycling.entity.RecyclingBatch;
import com.example.recycling.entity.RecyclingType;
import com.example.recycling.exception.ResourceNotFoundException;
import com.example.recycling.repository.BonusEntryRepository;
import com.example.recycling.repository.CollectionPointRepository;
import com.example.recycling.repository.RecyclingBatchRepository;
import com.example.recycling.repository.RecyclingTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Transactional
public class CollectionPointService {

    private final CollectionPointRepository collectionPointRepository;
    private final RecyclingTypeRepository recyclingTypeRepository;
    private final RecyclingBatchRepository recyclingBatchRepository;
    private final BonusEntryRepository bonusEntryRepository;

    public CollectionPointService(CollectionPointRepository collectionPointRepository,
                                  RecyclingTypeRepository recyclingTypeRepository,
                                  RecyclingBatchRepository recyclingBatchRepository,
                                  BonusEntryRepository bonusEntryRepository) {
        this.collectionPointRepository = collectionPointRepository;
        this.recyclingTypeRepository = recyclingTypeRepository;
        this.recyclingBatchRepository = recyclingBatchRepository;
        this.bonusEntryRepository = bonusEntryRepository;
    }

    @Transactional(readOnly = true)
    public List<CollectionPoint> getAllPoints() {
        return collectionPointRepository.findAll();
    }

    @Transactional(readOnly = true)
    public CollectionPoint getPointById(Long id) {
        return collectionPointRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Пункт приёма с id " + id + " не найден"));
    }

    public CollectionPoint createPoint(CollectionPoint point, Set<Long> acceptedTypeIds) {
        point.setId(null);
        if (acceptedTypeIds != null && !acceptedTypeIds.isEmpty()) {
            List<RecyclingType> types = recyclingTypeRepository.findAllById(acceptedTypeIds);
            point.setAcceptedTypes(new HashSet<>(types));
        } else {
            point.setAcceptedTypes(new HashSet<>());
        }
        return collectionPointRepository.save(point);
    }

    public CollectionPoint updatePoint(Long id, CollectionPoint patchData, Set<Long> acceptedTypeIds) {
        CollectionPoint existing = getPointById(id);

        if (patchData.getAddress() != null) {
            existing.setAddress(patchData.getAddress());
        }
        if (patchData.getAvailable() != null) {
            existing.setAvailable(patchData.getAvailable());
        }
        if (patchData.getDailyWeightLimit() != null) {
            existing.setDailyWeightLimit(patchData.getDailyWeightLimit());
        }
        if (acceptedTypeIds != null) {
            List<RecyclingType> types = recyclingTypeRepository.findAllById(acceptedTypeIds);
            existing.setAcceptedTypes(new HashSet<>(types));
        }

        return collectionPointRepository.save(existing);
    }

    public void deletePoint(Long id) {
        CollectionPoint point = getPointById(id);

        point.getAcceptedTypes().clear();
        collectionPointRepository.save(point);

        List<RecyclingBatch> batches = recyclingBatchRepository.findByCollectionPointId(id);
        for (RecyclingBatch batch : batches) {
            List<BonusEntry> bonuses = bonusEntryRepository.findByRecyclingBatchId(batch.getId());
            bonusEntryRepository.deleteAll(bonuses);
            recyclingBatchRepository.delete(batch);
        }

        collectionPointRepository.delete(point);
    }
}
