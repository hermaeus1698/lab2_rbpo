package com.example.recycling.service;

import com.example.recycling.entity.*;
import com.example.recycling.exception.ResourceNotFoundException;
import com.example.recycling.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class RecyclingBatchService {

    private final RecyclingBatchRepository recyclingBatchRepository;
    private final UserRepository userRepository;
    private final CollectionPointRepository collectionPointRepository;
    private final RecyclingTypeRepository recyclingTypeRepository;
    private final BonusEntryRepository bonusEntryRepository;

    public RecyclingBatchService(RecyclingBatchRepository recyclingBatchRepository,
                                 UserRepository userRepository,
                                 CollectionPointRepository collectionPointRepository,
                                 RecyclingTypeRepository recyclingTypeRepository,
                                 BonusEntryRepository bonusEntryRepository) {
        this.recyclingBatchRepository = recyclingBatchRepository;
        this.userRepository = userRepository;
        this.collectionPointRepository = collectionPointRepository;
        this.recyclingTypeRepository = recyclingTypeRepository;
        this.bonusEntryRepository = bonusEntryRepository;
    }

    @Transactional(readOnly = true)
    public List<RecyclingBatch> getAllBatches() {
        return recyclingBatchRepository.findAll();
    }

    @Transactional(readOnly = true)
    public RecyclingBatch getBatchById(Long id) {
        return recyclingBatchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Партия сдачи с id " + id + " не найдена"));
    }

    public RecyclingBatch createBatch(Long userId, Long pointId, Long typeId, Double weight, String status) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Пользователь с id " + userId + " не найден"));

        CollectionPoint point = collectionPointRepository.findById(pointId)
                .orElseThrow(() -> new ResourceNotFoundException("Пункт приёма с id " + pointId + " не найден"));

        RecyclingType type = recyclingTypeRepository.findById(typeId)
                .orElseThrow(() -> new ResourceNotFoundException("Вид вторсырья с id " + typeId + " не найден"));

        RecyclingBatch batch = new RecyclingBatch();
        batch.setUser(user);
        batch.setCollectionPoint(point);
        batch.setRecyclingType(type);
        batch.setWeight(weight != null ? weight : 0.0);

        batch.setReceptionDate(LocalDateTime.now());
        batch.setStatus(status != null ? status : "CREATED");

        return recyclingBatchRepository.save(batch);
    }

    public RecyclingBatch updateBatch(Long id, Long userId, Long pointId, Long typeId, Double weight, String status) {
        RecyclingBatch existing = getBatchById(id);

        if (userId != null) {
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new ResourceNotFoundException("Пользователь с id " + userId + " не найден"));
            existing.setUser(user);
        }
        if (pointId != null) {
            CollectionPoint point = collectionPointRepository.findById(pointId)
                    .orElseThrow(() -> new ResourceNotFoundException("Пункт приёма с id " + pointId + " не найден"));
            existing.setCollectionPoint(point);
        }
        if (typeId != null) {
            RecyclingType type = recyclingTypeRepository.findById(typeId)
                    .orElseThrow(() -> new ResourceNotFoundException("Вид вторсырья с id " + typeId + " не найден"));
            existing.setRecyclingType(type);
        }
        if (weight != null) {
            existing.setWeight(weight);
        }
        if (status != null) {
            existing.setStatus(status);
        }

        return recyclingBatchRepository.save(existing);
    }

    public void deleteBatch(Long id) {
        RecyclingBatch batch = getBatchById(id);

        List<BonusEntry> bonuses = bonusEntryRepository.findByRecyclingBatchId(id);
        bonusEntryRepository.deleteAll(bonuses);

        recyclingBatchRepository.delete(batch);
    }
}
