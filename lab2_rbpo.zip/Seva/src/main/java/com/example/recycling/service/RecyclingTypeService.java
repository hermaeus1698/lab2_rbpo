package com.example.recycling.service;

import com.example.recycling.entity.BonusEntry;
import com.example.recycling.entity.CollectionPoint;
import com.example.recycling.entity.RecyclingBatch;
import com.example.recycling.entity.RecyclingType;
import com.example.recycling.exception.ResourceNotFoundException;
import com.example.recycling.repository.BonusEntryRepository;
import com.example.recycling.repository.CollectionPointRepository;
import com.example.recycling.repository.RecyclingBatchRepository;
import com.example.recycling.repository.RecyclingTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class RecyclingTypeService {

    private final RecyclingTypeRepository recyclingTypeRepository;
    private final CollectionPointRepository collectionPointRepository;
    private final RecyclingBatchRepository recyclingBatchRepository;
    private final BonusEntryRepository bonusEntryRepository;

    public RecyclingTypeService(RecyclingTypeRepository recyclingTypeRepository,
                                CollectionPointRepository collectionPointRepository,
                                RecyclingBatchRepository recyclingBatchRepository,
                                BonusEntryRepository bonusEntryRepository) {
        this.recyclingTypeRepository = recyclingTypeRepository;
        this.collectionPointRepository = collectionPointRepository;
        this.recyclingBatchRepository = recyclingBatchRepository;
        this.bonusEntryRepository = bonusEntryRepository;
    }

    @Transactional(readOnly = true)
    public List<RecyclingType> getAllTypes() {
        return recyclingTypeRepository.findAll();
    }

    @Transactional(readOnly = true)
    public RecyclingType getTypeById(Long id) {
        return recyclingTypeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Вид вторсырья с id " + id + " не найден"));
    }

    public RecyclingType createType(RecyclingType type) {
        type.setId(null);
        return recyclingTypeRepository.save(type);
    }

    public RecyclingType updateType(Long id, RecyclingType patchData) {
        RecyclingType existing = getTypeById(id);

        if (patchData.getName() != null) {
            existing.setName(patchData.getName());
        }
        if (patchData.getUnit() != null) {
            existing.setUnit(patchData.getUnit());
        }
        if (patchData.getPointsPerKg() != null) {
            existing.setPointsPerKg(patchData.getPointsPerKg());
        }

        return recyclingTypeRepository.save(existing);
    }

    public void deleteType(Long id) {
        RecyclingType type = getTypeById(id);

        List<CollectionPoint> points = collectionPointRepository.findByAcceptedTypesContaining(type);
        for (CollectionPoint point : points) {
            point.getAcceptedTypes().remove(type);
            collectionPointRepository.save(point);
        }

        List<RecyclingBatch> batches = recyclingBatchRepository.findByRecyclingTypeId(id);
        for (RecyclingBatch batch : batches) {
            List<BonusEntry> bonuses = bonusEntryRepository.findByRecyclingBatchId(batch.getId());
            bonusEntryRepository.deleteAll(bonuses);
            recyclingBatchRepository.delete(batch);
        }

        recyclingTypeRepository.delete(type);
    }
}
