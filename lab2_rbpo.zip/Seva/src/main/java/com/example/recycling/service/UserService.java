package com.example.recycling.service;

import com.example.recycling.entity.BonusEntry;
import com.example.recycling.entity.RecyclingBatch;
import com.example.recycling.entity.User;
import com.example.recycling.exception.ResourceNotFoundException;
import com.example.recycling.repository.BonusEntryRepository;
import com.example.recycling.repository.RecyclingBatchRepository;
import com.example.recycling.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final RecyclingBatchRepository recyclingBatchRepository;
    private final BonusEntryRepository bonusEntryRepository;

    public UserService(UserRepository userRepository,
                       RecyclingBatchRepository recyclingBatchRepository,
                       BonusEntryRepository bonusEntryRepository) {
        this.userRepository = userRepository;
        this.recyclingBatchRepository = recyclingBatchRepository;
        this.bonusEntryRepository = bonusEntryRepository;
    }

    @Transactional(readOnly = true)
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Transactional(readOnly = true)
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Пользователь с id " + id + " не найден"));
    }

    public User createUser(User user) {
        user.setId(null);
        return userRepository.save(user);
    }

    public User updateUser(Long id, User patchData) {
        User existing = getUserById(id);

        if (patchData.getName() != null) {
            existing.setName(patchData.getName());
        }
        if (patchData.getEmail() != null) {
            existing.setEmail(patchData.getEmail());
        }
        if (patchData.getPhoneNumber() != null) {
            existing.setPhoneNumber(patchData.getPhoneNumber());
        }

        return userRepository.save(existing);
    }

    public void deleteUser(Long id) {
        User user = getUserById(id);

        List<RecyclingBatch> batches = recyclingBatchRepository.findByUserId(id);
        for (RecyclingBatch batch : batches) {
            List<BonusEntry> bonuses = bonusEntryRepository.findByRecyclingBatchId(batch.getId());
            bonusEntryRepository.deleteAll(bonuses);
            recyclingBatchRepository.delete(batch);
        }

        userRepository.delete(user);
    }
}
